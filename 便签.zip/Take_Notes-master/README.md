# Take_Notes
Android便签Demo

具体可以参考博客：https://blog.csdn.net/qq_38442065/article/details/80309622
